
CREATE TABLE users(id SERIAL PRIMARY KEY,username TEXT,password TEXT,role TEXT);
CREATE TABLE menu(id SERIAL PRIMARY KEY,name TEXT,price NUMERIC);
CREATE TABLE orders(id SERIAL PRIMARY KEY,user_id INT,total NUMERIC,status TEXT,created_at TIMESTAMP DEFAULT NOW());
CREATE TABLE order_items(id SERIAL PRIMARY KEY,order_id INT,menu_id INT,quantity INT,price NUMERIC);
CREATE TABLE notifications(id SERIAL PRIMARY KEY,receiver_id INT,message TEXT,is_read BOOLEAN DEFAULT FALSE,created_at TIMESTAMP DEFAULT NOW());
CREATE TABLE reviews(id SERIAL PRIMARY KEY,user_id INT,content TEXT,created_at TIMESTAMP DEFAULT NOW());
