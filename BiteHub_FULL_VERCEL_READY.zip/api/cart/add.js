
export default (req,res)=>{ res.json({ok:true}); };
